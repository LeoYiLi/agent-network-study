# 2x2 factorial — axis2x2
episodes=72

## requirement F1 (T1 cold)
```
                sandbox     store
  open         0.777      0.920     A,B
  bounded      0.607      0.625     C,D
```
  d_access    =  0.080   95% CI [-0.011,  0.175]   spans 0
  d_discovery =  0.232   95% CI [ 0.127,  0.316]   excludes 0
  |access| / |discovery| = 0.35
    E=0.3:  access  0.090   discovery  0.112
    E=0.7:  access  0.071   discovery  0.352

## requirement F1 (T2 rework)
```
                sandbox     store
  open         0.806      0.839     A,B
  bounded      0.697      0.721     C,D
```
  d_access    =  0.028   95% CI [-0.052,  0.113]   spans 0
  d_discovery =  0.114   95% CI [ 0.031,  0.198]   excludes 0
  |access| / |discovery| = 0.25
    E=0.3:  access -0.002   discovery -0.037
    E=0.7:  access  0.058   discovery  0.265

## requirement F1 (T3 warm)
```
                sandbox     store
  open         0.804      0.911     A,B
  bounded      0.544      0.632     C,D
```
  d_access    =  0.098   95% CI [ 0.021,  0.169]   excludes 0
  d_discovery =  0.269   95% CI [ 0.189,  0.334]   excludes 0
  |access| / |discovery| = 0.36
    E=0.3:  access  0.141   discovery  0.148
    E=0.7:  access  0.055   discovery  0.391

## assertions passed (T1)
```
                sandbox     store
  open         0.771      0.910     A,B
  bounded      0.566      0.574     C,D
```
  d_access    =  0.073   95% CI [-0.020,  0.170]   spans 0
  d_discovery =  0.271   95% CI [ 0.163,  0.357]   excludes 0
  |access| / |discovery| = 0.27
    E=0.3:  access  0.082   discovery  0.142
    E=0.7:  access  0.065   discovery  0.400

## pollution absorbed (T1)
```
                sandbox     store
  open         1.889      1.944     A,B
  bounded      2.056      1.944     C,D
```
  d_access    = -0.028   95% CI [-0.278,  0.222]   spans 0
  d_discovery = -0.083   95% CI [-0.333,  0.194]   spans 0
  |access| / |discovery| = 0.33
    E=0.3:  access -0.056   discovery  0.056
    E=0.7:  access -0.000   discovery -0.222

## tokens (T1, k)
```
                sandbox     store
  open         43.851      58.702     A,B
  bounded      64.832      72.015     C,D
```
  d_access    =  11.017   95% CI [ 4.050,  18.704]   excludes 0
  d_discovery = -17.147   95% CI [-24.690, -10.365]   excludes 0
  |access| / |discovery| = 0.64
    E=0.3:  access  8.786   discovery -23.452
    E=0.7:  access  13.248   discovery -10.841

## contacts (T1)
```
                sandbox     store
  open         5.778      6.667     A,B
  bounded      5.167      4.222     C,D
```
  d_access    = -0.028   95% CI [-1.139,  1.083]   spans 0
  d_discovery =  1.528   95% CI [ 0.361,  2.639]   excludes 0
  |access| / |discovery| = 0.02
    E=0.3:  access -0.167   discovery  0.833
    E=0.7:  access  0.111   discovery  2.222

## H4 — affordance use (store cells only)
| arm | asks/T1 | lists/T1 | reads/T1 | store share |
|---|---|---|---|---|
| B | 6.2 | 5.0 | 7.2 | 0.66 |
| D | 4.6 | 3.9 | 3.6 | 0.62 |

A store share near zero is H4 confirmed: the affordance exists and is not used.