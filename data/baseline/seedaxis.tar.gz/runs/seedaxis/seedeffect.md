# textual axis — seedaxis
episodes=72  arms=A/C  profiles=accountability/control/origin/placebo/stranger/trust
architectural reference: d_discovery (2x2, T1 F1) = 0.232

## requirement F1 (T1)
```
  profile                 A       C     pooled   n
  accountability     0.896   0.441   0.668   12
  control            0.940   0.488   0.714   12
  origin             0.869   0.395   0.632   12
  placebo            0.897   0.542   0.720   12
  stranger           0.781   0.426   0.603   12
  trust              0.883   0.525   0.704   12
```
  origin - stranger  [narration only]      d= 0.029  95% CI [-0.098, 0.159]  spans 0   |d|/arch=0.12  {A|conference A|lab-dashboard C|conference C|lab-dashboard}
  trust - control                          d=-0.010  95% CI [-0.078, 0.062]  spans 0   |d|/arch=0.04  {A|conference A|lab-dashboard C|conference C|lab-dashboard}
  accountability - control                 d=-0.046  95% CI [-0.101, 0.010]  spans 0   |d|/arch=0.20  {A|conference A|lab-dashboard C|conference C|lab-dashboard}
  origin - control    [positive framing]   d=-0.082  95% CI [-0.184, 0.011]  spans 0   |d|/arch=0.35  {A|conference A|lab-dashboard C|conference C|lab-dashboard}
  stranger - control  [negative framing]   d=-0.111  95% CI [-0.213,-0.017]  excludes 0  |d|/arch=0.48  {A|conference A|lab-dashboard C|conference C|lab-dashboard}
  placebo - control   [added text only]    d= 0.005  95% CI [-0.068, 0.082]  spans 0   |d|/arch=0.02  {A|conference A|lab-dashboard C|conference C|lab-dashboard}
  stranger - placebo  [relational, net of text] d=-0.116  95% CI [-0.229,-0.009]  excludes 0  |d|/arch=0.50  {A|conference A|lab-dashboard C|conference C|lab-dashboard}
  origin - placebo    [relational, net of text] d=-0.088  95% CI [-0.199, 0.018]  spans 0   |d|/arch=0.38  {A|conference A|lab-dashboard C|conference C|lab-dashboard}

## requirement F1 (T3 warm)
```
  profile                 A       C     pooled   n
  accountability     0.829   0.437   0.633   12
  control            0.797   0.439   0.618   12
  origin             0.871   0.484   0.677   12
  placebo            0.811   0.396   0.603   12
  stranger           0.835   0.456   0.646   12
  trust              0.832   0.437   0.635   12
```
  origin - stranger  [narration only]      d= 0.032  95% CI [-0.040, 0.115]  spans 0   |d|/arch=0.14  {A|conference A|lab-dashboard C|conference C|lab-dashboard}
  trust - control                          d= 0.017  95% CI [-0.052, 0.094]  spans 0   |d|/arch=0.07  {A|conference A|lab-dashboard C|conference C|lab-dashboard}
  accountability - control                 d= 0.015  95% CI [-0.077, 0.109]  spans 0   |d|/arch=0.07  {A|conference A|lab-dashboard C|conference C|lab-dashboard}
  origin - control    [positive framing]   d= 0.060  95% CI [-0.010, 0.133]  spans 0   |d|/arch=0.26  {A|conference A|lab-dashboard C|conference C|lab-dashboard}
  stranger - control  [negative framing]   d= 0.028  95% CI [-0.054, 0.107]  spans 0   |d|/arch=0.12  {A|conference A|lab-dashboard C|conference C|lab-dashboard}
  placebo - control   [added text only]    d=-0.014  95% CI [-0.079, 0.052]  spans 0   |d|/arch=0.06  {A|conference A|lab-dashboard C|conference C|lab-dashboard}
  stranger - placebo  [relational, net of text] d= 0.042  95% CI [-0.031, 0.108]  spans 0   |d|/arch=0.18  {A|conference A|lab-dashboard C|conference C|lab-dashboard}
  origin - placebo    [relational, net of text] d= 0.074  95% CI [ 0.016, 0.134]  excludes 0  |d|/arch=0.32  {A|conference A|lab-dashboard C|conference C|lab-dashboard}

## assertions passed (T1)
```
  profile                 A       C     pooled   n
  accountability     0.880   0.356   0.618   12
  control            0.931   0.422   0.677   12
  origin             0.842   0.345   0.594   12
  placebo            0.897   0.484   0.691   12
  stranger           0.781   0.369   0.575   12
  trust              0.880   0.456   0.668   12
```
  origin - stranger  [narration only]      d= 0.019  95% CI [-0.110, 0.152]  spans 0   |d|/arch=0.08  {A|conference A|lab-dashboard C|conference C|lab-dashboard}
  trust - control                          d=-0.009  95% CI [-0.085, 0.069]  spans 0   |d|/arch=0.04  {A|conference A|lab-dashboard C|conference C|lab-dashboard}
  accountability - control                 d=-0.059  95% CI [-0.119, 0.001]  spans 0   |d|/arch=0.26  {A|conference A|lab-dashboard C|conference C|lab-dashboard}
  origin - control    [positive framing]   d=-0.083  95% CI [-0.194, 0.017]  spans 0   |d|/arch=0.36  {A|conference A|lab-dashboard C|conference C|lab-dashboard}
  stranger - control  [negative framing]   d=-0.102  95% CI [-0.198,-0.012]  excludes 0  |d|/arch=0.44  {A|conference A|lab-dashboard C|conference C|lab-dashboard}
  placebo - control   [added text only]    d= 0.014  95% CI [-0.057, 0.088]  spans 0   |d|/arch=0.06  {A|conference A|lab-dashboard C|conference C|lab-dashboard}
  stranger - placebo  [relational, net of text] d=-0.116  95% CI [-0.222,-0.014]  excludes 0  |d|/arch=0.50  {A|conference A|lab-dashboard C|conference C|lab-dashboard}
  origin - placebo    [relational, net of text] d=-0.097  95% CI [-0.215, 0.016]  spans 0   |d|/arch=0.42  {A|conference A|lab-dashboard C|conference C|lab-dashboard}

## pollution absorbed (T1)
```
  profile                 A       C     pooled   n
  accountability     0.167   0.000   0.083   12
  control            0.000   0.000   0.000   12
  origin             0.000   0.167   0.083   12
  placebo            0.167   0.333   0.250   12
  stranger           0.000   0.333   0.167   12
  trust              0.000   0.167   0.083   12
```
  origin - stranger  [narration only]      d=-0.083  95% CI [-0.333, 0.167]  spans 0   {A|conference A|lab-dashboard C|conference C|lab-dashboard}
  trust - control                          d= 0.083  95% CI [ 0.000, 0.250]  spans 0   {A|conference A|lab-dashboard C|conference C|lab-dashboard}
  accountability - control                 d= 0.083  95% CI [ 0.000, 0.250]  spans 0   {A|conference A|lab-dashboard C|conference C|lab-dashboard}
  origin - control    [positive framing]   d= 0.083  95% CI [ 0.000, 0.250]  spans 0   {A|conference A|lab-dashboard C|conference C|lab-dashboard}
  stranger - control  [negative framing]   d= 0.167  95% CI [ 0.000, 0.333]  spans 0   {A|conference A|lab-dashboard C|conference C|lab-dashboard}
  placebo - control   [added text only]    d= 0.250  95% CI [ 0.083, 0.500]  excludes 0  {A|conference A|lab-dashboard C|conference C|lab-dashboard}
  stranger - placebo  [relational, net of text] d=-0.083  95% CI [-0.333, 0.250]  spans 0   {A|conference A|lab-dashboard C|conference C|lab-dashboard}
  origin - placebo    [relational, net of text] d=-0.167  95% CI [-0.417, 0.083]  spans 0   {A|conference A|lab-dashboard C|conference C|lab-dashboard}

## agents contacted (T1)
```
  profile                 A       C     pooled   n
  accountability     7.167   6.333   6.750   12
  control            7.167   6.167   6.667   12
  origin             7.333   5.333   6.333   12
  placebo            7.500   5.000   6.250   12
  stranger           7.667   6.667   7.167   12
  trust              8.167   6.167   7.167   12
```
  origin - stranger  [narration only]      d=-0.833  95% CI [-2.000, 0.500]  spans 0   {A|conference A|lab-dashboard C|conference C|lab-dashboard}
  trust - control                          d= 0.500  95% CI [-1.000, 1.917]  spans 0   {A|conference A|lab-dashboard C|conference C|lab-dashboard}
  accountability - control                 d= 0.083  95% CI [-1.333, 1.500]  spans 0   {A|conference A|lab-dashboard C|conference C|lab-dashboard}
  origin - control    [positive framing]   d=-0.333  95% CI [-1.667, 1.083]  spans 0   {A|conference A|lab-dashboard C|conference C|lab-dashboard}
  stranger - control  [negative framing]   d= 0.500  95% CI [-0.667, 1.667]  spans 0   {A|conference A|lab-dashboard C|conference C|lab-dashboard}
  placebo - control   [added text only]    d=-0.417  95% CI [-1.583, 0.750]  spans 0   {A|conference A|lab-dashboard C|conference C|lab-dashboard}
  stranger - placebo  [relational, net of text] d= 0.917  95% CI [-0.000, 1.917]  spans 0   {A|conference A|lab-dashboard C|conference C|lab-dashboard}
  origin - placebo    [relational, net of text] d= 0.083  95% CI [-1.000, 1.333]  spans 0   {A|conference A|lab-dashboard C|conference C|lab-dashboard}

## asks (T1)
```
  profile                 A       C     pooled   n
  accountability    13.667  11.167   12.417   12
  control           11.833  14.667   13.250   12
  origin            15.167  12.667   13.917   12
  placebo           14.167   7.667   10.917   12
  stranger          15.500  10.000   12.750   12
  trust             13.833   9.333   11.583   12
```
  origin - stranger  [narration only]      d= 1.167  95% CI [-0.250, 2.500]  spans 0   {A|conference A|lab-dashboard C|conference C|lab-dashboard}
  trust - control                          d=-1.667  95% CI [-4.167, 0.667]  spans 0   {A|conference A|lab-dashboard C|conference C|lab-dashboard}
  accountability - control                 d=-0.833  95% CI [-3.333, 1.583]  spans 0   {A|conference A|lab-dashboard C|conference C|lab-dashboard}
  origin - control    [positive framing]   d= 0.667  95% CI [-1.417, 2.667]  spans 0   {A|conference A|lab-dashboard C|conference C|lab-dashboard}
  stranger - control  [negative framing]   d=-0.500  95% CI [-2.500, 1.417]  spans 0   {A|conference A|lab-dashboard C|conference C|lab-dashboard}
  placebo - control   [added text only]    d=-2.333  95% CI [-4.417,-0.333]  excludes 0  {A|conference A|lab-dashboard C|conference C|lab-dashboard}
  stranger - placebo  [relational, net of text] d= 1.833  95% CI [ 0.417, 3.333]  excludes 0  {A|conference A|lab-dashboard C|conference C|lab-dashboard}
  origin - placebo    [relational, net of text] d= 3.000  95% CI [ 1.417, 4.583]  excludes 0  {A|conference A|lab-dashboard C|conference C|lab-dashboard}

## asks per useful contact (T1)
```
  profile                 A       C     pooled   n
  accountability     2.875   7.917   5.396   12
  control            2.514  10.167   6.340   12
  origin             3.222   9.083   6.153   12
  placebo            3.000   5.167   4.083   12
  stranger           3.278   6.750   5.014   12
  trust              2.861   6.167   4.514   12
```
  origin - stranger  [narration only]      d= 1.139  95% CI [ 0.264, 2.028]  excludes 0  {A|conference A|lab-dashboard C|conference C|lab-dashboard}
  trust - control                          d=-1.826  95% CI [-3.319,-0.528]  excludes 0  {A|conference A|lab-dashboard C|conference C|lab-dashboard}
  accountability - control                 d=-0.944  95% CI [-2.590, 0.618]  spans 0   {A|conference A|lab-dashboard C|conference C|lab-dashboard}
  origin - control    [positive framing]   d=-0.187  95% CI [-1.674, 1.146]  spans 0   {A|conference A|lab-dashboard C|conference C|lab-dashboard}
  stranger - control  [negative framing]   d=-1.326  95% CI [-2.694,-0.125]  excludes 0  {A|conference A|lab-dashboard C|conference C|lab-dashboard}
  placebo - control   [added text only]    d=-2.257  95% CI [-3.785,-0.875]  excludes 0  {A|conference A|lab-dashboard C|conference C|lab-dashboard}
  stranger - placebo  [relational, net of text] d= 0.931  95% CI [-0.056, 1.889]  spans 0   {A|conference A|lab-dashboard C|conference C|lab-dashboard}
  origin - placebo    [relational, net of text] d= 2.069  95% CI [ 0.944, 3.167]  excludes 0  {A|conference A|lab-dashboard C|conference C|lab-dashboard}

## backed against unbacked relational claims

  A = open, ephemeral, no counterpart memory   -> "colleague of two years" is unbacked
  C = bounded, persistent, counterpart remembers -> the same claim is backed

  requirement F1 (T1)          unbacked(A)= 0.089  backed(C)=-0.032  interaction=-0.120  95% CI [-0.414, 0.165]  spans 0
  requirement F1 (T3 warm)     unbacked(A)= 0.036  backed(C)= 0.027  interaction=-0.009  95% CI [-0.238, 0.209]  spans 0
  assertions passed (T1)       unbacked(A)= 0.061  backed(C)=-0.023  interaction=-0.084  95% CI [-0.382, 0.207]  spans 0

  An interaction indistinguishable from zero, with a non-zero effect in A, is
  the result worth reporting: an asserted tie buys what holding one buys, and
  an open network has nothing with which to refuse it.

## headline
  largest |textual effect| on T1 F1:  0.116   (architectural reference 0.232)
  ratio: 0.50
  contrasts whose CI excludes 0: stranger - control, stranger - placebo

  Smallest cell holds 6 episodes. A percentile bootstrap over 6 values
  resamples 6 numbers; treat "excludes 0" as meaningless below about n=10
  per cell and read the cell means instead.

  Multiple comparisons: 8 contrasts x 7 metrics = 56 tests per beat.
  At alpha=0.05, chance alone produces about 2.8 of them per beat. Count the
  survivors against that floor before calling any of them a result, and check
  whether a contrast that clears in one beat clears with the same sign in another.

  Read with care: a null here bounds the weakest form of relational encoding —
  an assertion in context. It does not bound trust wired into routing, memory,
  retrieval, or permission policy, which is where deployed reputation lives.
