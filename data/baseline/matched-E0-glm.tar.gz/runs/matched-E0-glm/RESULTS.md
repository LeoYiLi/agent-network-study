# agent-network-study — matched-E0-glm
model=z-ai/glm-4.6  episodes=18  calls=1622  cost=$2.339  elapsed=47min

## Requirement F1 by arm and beat
| arm | T1 cold | T2 rework | T3 warm | T4 warm-rework |
|---|---|---|---|---|
| private | 0.57 | 0.78 | 0.61 | 0.57 |
| public | 0.45 | 0.84 | 0.58 | 0.68 |
| hybrid | 0.59 | 0.59 | 0.39 | 0.56 |

## Cost in tokens by arm and beat
| arm | T1 | T2 | T3 | T4 | warm speedup | rework decay |
|---|---|---|---|---|---|---|
| private | 48752 | 42972 | 43334 | 42414 | 0.11 | -0.01 |
| public | 44912 | 36720 | 51671 | 33895 | -0.21 | 0.04 |
| hybrid | 42066 | 41920 | 43619 | 32333 | -0.04 | 0.14 |

## Regression: untouched assertions that broke during rework (lower is better)
| arm | T2 | T4 |
|---|---|---|
| private | 1.33 | 2.17 |
| public | 0.67 | 2.00 |
| hybrid | 0.83 | 1.50 |

## Search and pollution (all beats pooled)
| arm | contacted | useful | search precision | pollution seen | absorbed |
|---|---|---|---|---|---|
| private | 4.63 | 4.25 | 0.92 | 3.50 | 1.79 |
| public | 5.50 | 4.00 | 0.74 | 3.29 | 1.96 |
| hybrid | 5.42 | 3.83 | 0.71 | 3.29 | 1.79 |

## By external fraction E (T1 cold F1)
| arm | E=0 |
|---|---|
| private | 0.57 |
| public | 0.45 |
| hybrid | 0.59 |

## Sub-delegation (builders consulting a further specialist)
| arm | consults per beat | max depth reached |
|---|---|---|
| private | 0.00 | 0 |
| public | 0.00 | 0 |
| hybrid | 0.00 | 0 |

## Kernel decisions (SharedOS)
| arm | grants minted | allowed | denied | reasons | max delegation depth |
|---|---|---|---|---|---|
| private | 32 | 32 | 0 | - | 0 |
| public | 33 | 33 | 0 | - | 0 |
| hybrid | 30 | 30 | 0 | - | 0 |

## Paired comparison, public minus private
Cells are paired on (scenario, E, seed), so the difference is within-condition.
| beat | mean diff in F1 | private wins | public wins | ties |
|---|---|---|---|---|
| T1 | -0.12 | 4 | 1 | 1 |
| T2 | 0.06 | 2 | 3 | 1 |
| T3 | -0.03 | 3 | 2 | 1 |
| T4 | 0.12 | 3 | 2 | 1 |

## Spread across seeds (T1 cold F1, min..max per arm)
| arm | min | mean | max | n |
|---|---|---|---|---|
| private | 0.00 | 0.57 | 0.90 | 6 |
| public | 0.00 | 0.45 | 1.00 | 6 |
| hybrid | 0.36 | 0.59 | 0.97 | 6 |

## Health
- beats: 72, artifacts parsed: 67, calculator present: 67
- beats with no artifact: 4
- most-failed assertions: a_costs(18) c_early1(17) a_lat_c(17) c_grp5(16) a_adult(16) a_dri_c(15) c_fam(15) c_2a3c(15) a_d3(14) c_2a1c(14)

## What these numbers do and do not support
- Sub-delegation fired 0 times across 72 beats; delegation depth was **never exercised**.
  The delegation-depth knob is therefore UNTESTED in this run: builders reported no missing facts, so the kernel was never asked to pass a mandate on. Do not claim a delegation result.
- 4 beats produced no artifact and score 0; check those episodes before reading any mean.
- The cold-phase reach difference is fixed by the E allocation, so a T1 gap is a property of the design. T2/T3/T4 differences are not.
- Scores are exact-match against pre-verified keys, with no model in the scoring loop.
