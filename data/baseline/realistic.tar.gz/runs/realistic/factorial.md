# 2x2 factorial — realistic
episodes=72

## requirement F1 (T1 cold)
```
                sandbox     store
  open         0.795      0.901     A,B
  bounded      0.552      0.594     C,D
```
  d_access    =  0.074   95% CI [-0.005,  0.159]   spans 0
  d_discovery =  0.275   95% CI [ 0.189,  0.360]   excludes 0
  |access| / |discovery| = 0.27
    E=0.3:  access  0.112   discovery  0.205
    E=0.7:  access  0.036   discovery  0.345

## requirement F1 (T2 rework)
```
                sandbox     store
  open         0.816      0.860     A,B
  bounded      0.694      0.720     C,D
```
  d_access    =  0.035   95% CI [-0.038,  0.104]   spans 0
  d_discovery =  0.131   95% CI [ 0.065,  0.206]   excludes 0
  |access| / |discovery| = 0.26
    E=0.3:  access  0.032   discovery  0.048
    E=0.7:  access  0.038   discovery  0.214

## requirement F1 (T3 warm)
```
                sandbox     store
  open         0.778      0.846     A,B
  bounded      0.513      0.587     C,D
```
  d_access    =  0.071   95% CI [-0.007,  0.142]   spans 0
  d_discovery =  0.262   95% CI [ 0.191,  0.341]   excludes 0
  |access| / |discovery| = 0.27
    E=0.3:  access  0.067   discovery  0.170
    E=0.7:  access  0.074   discovery  0.354

## assertions passed (T1)
```
                sandbox     store
  open         0.789      0.898     A,B
  bounded      0.501      0.554     C,D
```
  d_access    =  0.081   95% CI [ 0.003,  0.164]   excludes 0
  d_discovery =  0.316   95% CI [ 0.229,  0.400]   excludes 0
  |access| / |discovery| = 0.26
    E=0.3:  access  0.121   discovery  0.235
    E=0.7:  access  0.040   discovery  0.397

## pollution absorbed (T1)
```
                sandbox     store
  open         0.056      0.000     A,B
  bounded      0.222      0.556     C,D
```
  d_access    =  0.139   95% CI [-0.028,  0.306]   spans 0
  d_discovery = -0.361   95% CI [-0.528, -0.194]   excludes 0
  |access| / |discovery| = 0.38
    E=0.3:  access  0.111   discovery -0.222
    E=0.7:  access  0.167   discovery -0.500

## tokens (T1, k)
```
                sandbox     store
  open         56.438      62.471     A,B
  bounded      65.203      67.581     C,D
```
  d_access    =  4.206   95% CI [-3.924,  11.750]   spans 0
  d_discovery = -6.938   95% CI [-15.167,  0.685]   spans 0
  |access| / |discovery| = 0.61
    E=0.3:  access -0.051   discovery -5.504
    E=0.7:  access  8.463   discovery -8.371

## contacts (T1)
```
                sandbox     store
  open         6.444      6.167     A,B
  bounded      4.889      4.833     C,D
```
  d_access    = -0.167   95% CI [-1.194,  0.833]   spans 0
  d_discovery =  1.444   95% CI [ 0.500,  2.444]   excludes 0
  |access| / |discovery| = 0.12
    E=0.3:  access -0.444   discovery  1.222
    E=0.7:  access  0.111   discovery  1.667

## H4 — affordance use (store cells only)
| arm | asks/T1 | lists/T1 | reads/T1 | store share |
|---|---|---|---|---|
| B | 6.2 | 4.4 | 6.2 | 0.63 |
| D | 5.1 | 4.2 | 2.7 | 0.58 |

A store share near zero is H4 confirmed: the affordance exists and is not used.