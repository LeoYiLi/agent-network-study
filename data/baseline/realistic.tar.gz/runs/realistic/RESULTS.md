# agent-network-study — realistic
model=deepseek/deepseek-v4-flash  episodes=72  calls=6779  cost=$1.746  elapsed=32min

## Delivery (read this before any contrast below)

- beats: 288, no artifact: 1 (0%)
- worst cell: arm=C E=0.3 at 3%; spread across cells 3%

| cell | beats | no artifact | rate |
|---|---|---|---|
| arm=C E=0.3 | 36 | 1 | 3% |
| arm=A E=0.3 | 36 | 0 | 0% |
| arm=A E=0.7 | 36 | 0 | 0% |
| arm=B E=0.3 | 36 | 0 | 0% |
| arm=B E=0.7 | 36 | 0 | 0% |
| arm=C E=0.7 | 36 | 0 | 0% |
| arm=D E=0.3 | 36 | 0 | 0% |
| arm=D E=0.7 | 36 | 0 | 0% |


## Requirement F1 by arm and beat
| arm | T1 cold | T2 rework | T3 warm | T4 warm-rework |
|---|---|---|---|---|
| A | 0.79 | 0.82 | 0.78 | 0.76 |
| B | 0.90 | 0.86 | 0.85 | 0.78 |
| C | 0.55 | 0.69 | 0.51 | 0.58 |
| D | 0.59 | 0.72 | 0.59 | 0.60 |

## Cost in tokens by arm and beat
| arm | T1 | T2 | T3 | T4 | warm speedup | rework decay |
|---|---|---|---|---|---|---|
| A | 56438 | 52917 | 57665 | 49477 | -0.11 | 0.02 |
| B | 62471 | 45502 | 58664 | 57401 | 0.03 | -0.34 |
| C | 65203 | 66725 | 70268 | 74606 | -0.17 | -0.18 |
| D | 67581 | 65373 | 77312 | 63808 | -0.22 | -0.01 |

## Regression: untouched assertions that broke during rework (lower is better)
| arm | T2 | T4 |
|---|---|---|
| A | 0.94 | 1.22 |
| B | 0.50 | 1.67 |
| C | 0.67 | 0.67 |
| D | 0.50 | 0.89 |

## Search and pollution (all beats pooled)
| arm | contacted | useful | search precision | pollution seen | absorbed |
|---|---|---|---|---|---|
| A | 6.07 | 4.53 | 0.75 | 3.90 | 0.08 |
| B | 5.81 | 4.43 | 0.77 | 3.68 | 0.18 |
| C | 4.32 | 2.22 | 0.54 | 0.94 | 0.24 |
| D | 4.47 | 2.15 | 0.48 | 0.92 | 0.42 |

## By external fraction E (T1 cold F1)
| arm | E=0.3 | E=0.7 |
|---|---|---|
| A | 0.78 | 0.80 |
| B | 0.90 | 0.90 |
| C | 0.59 | 0.52 |
| D | 0.69 | 0.50 |

## Sub-delegation (builders consulting a further specialist)
| arm | consults per beat | max depth reached |
|---|---|---|
| A | 0.00 | 0 |
| B | 0.00 | 0 |
| C | 0.00 | 0 |
| D | 0.00 | 0 |

## Kernel decisions (SharedOS)
| arm | grants minted | allowed | denied | reasons | max delegation depth |
|---|---|---|---|---|---|
| A | 43 | 43 | 0 | - | 0 |
| B | 56 | 56 | 0 | - | 0 |
| C | 40 | 40 | 0 | - | 0 |
| D | 47 | 47 | 0 | - | 0 |

## Paired comparison, public minus private
Cells are paired on (scenario, E, seed), so the difference is within-condition.
| beat | mean diff in F1 | private wins | public wins | ties |
|---|---|---|---|---|
| T1 |   -- | 0 | 0 | 0 |
| T2 |   -- | 0 | 0 | 0 |
| T3 |   -- | 0 | 0 | 0 |
| T4 |   -- | 0 | 0 | 0 |

## Spread across seeds (T1 cold F1, min..max per arm)
| arm | min | mean | max | n |
|---|---|---|---|---|
| A | 0.58 | 0.79 | 1.00 | 18 |
| B | 0.65 | 0.90 | 1.00 | 18 |
| C | 0.00 | 0.55 | 0.94 | 18 |
| D | 0.35 | 0.59 | 1.00 | 18 |

## Health
- beats: 288, artifacts parsed: 287, calculator present: 287
- beats with no artifact: 1
- most-failed assertions: c_early1(91) c_grp5(83) c_fam(71) c_2a3c(71) a_costs(68) c_2a1c(67) a_fees(60) c_1d(56) c_grp4(45) c_std_ws2(44)

## What these numbers do and do not support
- Sub-delegation fired 0 times across 288 beats; delegation depth was **never exercised**.
  The delegation-depth knob is therefore UNTESTED in this run: builders reported no missing facts, so the kernel was never asked to pass a mandate on. Do not claim a delegation result.
- 1 beats produced no artifact and score 0; check those episodes before reading any mean.
- The cold-phase reach difference is fixed by the E allocation, so a T1 gap is a property of the design. T2/T3/T4 differences are not.
- Scores are exact-match against pre-verified keys, with no model in the scoring loop.
