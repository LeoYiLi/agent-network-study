# agent-network-study — matched-E0
model=deepseek/deepseek-v4-flash  episodes=27  calls=2538  cost=$0.613  elapsed=98min

## Requirement F1 by arm and beat
| arm | T1 cold | T2 rework | T3 warm | T4 warm-rework |
|---|---|---|---|---|
| public | 0.90 | 0.83 | 0.83 | 0.46 |
| private | 0.87 | 0.92 | 0.74 | 0.63 |
| hybrid | 0.82 | 0.80 | 0.85 | 0.79 |

## Cost in tokens by arm and beat
| arm | T1 | T2 | T3 | T4 | warm speedup | rework decay |
|---|---|---|---|---|---|---|
| public | 56276 | 45088 | 49757 | 44906 | 0.03 | -0.00 |
| private | 52892 | 59245 | 81541 | 77735 | -0.71 | -0.41 |
| hybrid | 63428 | 46834 | 49471 | 51220 | 0.17 | -0.23 |

## Regression: untouched assertions that broke during rework (lower is better)
| arm | T2 | T4 |
|---|---|---|
| public | 0.78 | 1.33 |
| private | 0.56 | 2.89 |
| hybrid | 0.22 | 0.67 |

## Search and pollution (all beats pooled)
| arm | contacted | useful | search precision | pollution seen | absorbed |
|---|---|---|---|---|---|
| public | 6.08 | 4.28 | 0.68 | 3.67 | 1.89 |
| private | 5.44 | 4.36 | 0.81 | 3.67 | 1.83 |
| hybrid | 6.31 | 4.44 | 0.73 | 3.75 | 1.97 |

## By external fraction E (T1 cold F1)
| arm | E=0 |
|---|---|
| public | 0.90 |
| private | 0.87 |
| hybrid | 0.82 |

## Sub-delegation (builders consulting a further specialist)
| arm | consults per beat | max depth reached |
|---|---|---|
| public | 0.00 | 0 |
| private | 0.00 | 0 |
| hybrid | 0.00 | 0 |

## Kernel decisions (SharedOS)
| arm | grants minted | allowed | denied | reasons | max delegation depth |
|---|---|---|---|---|---|
| public | 39 | 39 | 0 | - | 0 |
| private | 45 | 45 | 0 | - | 0 |
| hybrid | 42 | 42 | 0 | - | 0 |

## Paired comparison, public minus private
Cells are paired on (scenario, E, seed), so the difference is within-condition.
| beat | mean diff in F1 | private wins | public wins | ties |
|---|---|---|---|---|
| T1 | 0.02 | 2 | 3 | 4 |
| T2 | -0.09 | 4 | 0 | 5 |
| T3 | 0.09 | 2 | 5 | 2 |
| T4 | -0.17 | 4 | 4 | 1 |

## Spread across seeds (T1 cold F1, min..max per arm)
| arm | min | mean | max | n |
|---|---|---|---|---|
| public | 0.63 | 0.90 | 1.00 | 9 |
| private | 0.58 | 0.87 | 1.00 | 9 |
| hybrid | 0.63 | 0.82 | 1.00 | 9 |

## Health
- beats: 108, artifacts parsed: 104, calculator present: 104
- beats with no artifact: 0
- most-failed assertions: c_early1(35) c_grp5(34) a_costs(32) a_fees(26) c_grp4(18) c_grp6(16) c_2a1c(15) c_fam(15) c_2a3c(15) a_monday(13)

## What these numbers do and do not support
- Sub-delegation fired 0 times across 108 beats; delegation depth was **never exercised**.
  The delegation-depth knob is therefore UNTESTED in this run: builders reported no missing facts, so the kernel was never asked to pass a mandate on. Do not claim a delegation result.
- The cold-phase reach difference is fixed by the E allocation, so a T1 gap is a property of the design. T2/T3/T4 differences are not.
- Scores are exact-match against pre-verified keys, with no model in the scoring loop.
